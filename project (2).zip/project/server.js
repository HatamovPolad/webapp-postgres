const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg'); // PostgreSQL module
const path = require('path'); // To handle file paths
const app = express();
const PORT = 3000;
const cors = require('cors');




// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'PONY'))); // Updated to serve static files from 'PONY'
app.use(cors());
 

// PostgreSQL connection
const db = new Pool({
  host: 'localhost',
  user: 'postgres',
  password: '2006', 
  database: 'pony_db',
  port: 5432,
});

// Database connection test
db.connect((err) => {
  if (err) {
    console.error('Failed to connect to the database:', err);
    process.exit(1);
  } else {
    console.log('Connected to the database');
  }
});


          /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Routes


// Add Parent (using stored procedure)
app.post('/add-parent', async (req, res) => {
  console.log(req.body); // Gelen veriyi kontrol edin
  const { parent_name, parent_surname } = req.body;

  if (!parent_name || !parent_surname) {
    return res.status(400).send('Eksik veri gönderildi.');
  }

  const sql = 'CALL add_parent($1, $2)';

  try {
    await db.query(sql, [parent_name, parent_surname]);
    res.send('Ebeveyn başarıyla eklendi.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Ebeveyn eklenirken bir hata oluştu.');
  }
});


//Delete Parent
app.delete('/parents/:parent_id', async (req, res) => {
  const parentId = req.params.parent_id;

  try {
    const deleteSql = 'DELETE FROM ebeveynler WHERE parent_id = $1 RETURNING *';
    const result = await db.query(deleteSql, [parentId]);

    if (result.rowCount === 0) {
      return res.status(404).send('Ebeveyn bulunamadı.');
    }

    res.send('Ebeveyn ve bağlantılı çocuk bilgileri başarıyla güncellendi.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Ebeveyn silinirken bir hata oluştu.');
  }
});




// Update Parent
app.put('/parents/:parent_id', async (req, res) => {
  const parentId = req.params.parent_id;
  const { parent_name, parent_surname } = req.body;

  // Eğer güncellenecek alan yoksa hata döndür
  if (!parent_name && !parent_surname) {
    return res.status(400).send('Güncellemek için en az bir alan belirtilmelidir.');
  }

  const fields = [];
  const values = [];
  let counter = 1;

  if (parent_name) {
    fields.push(`parent_name = $${counter++}`);
    values.push(parent_name);
  }
  if (parent_surname) {
    fields.push(`parent_surname = $${counter++}`);
    values.push(parent_surname);
  }

  // Güncelleme sorgusunu oluştur
  const sql = `UPDATE ebeveynler SET ${fields.join(', ')} WHERE parent_id = $${counter} RETURNING *`;
  values.push(parentId);

  try {
    const result = await db.query(sql, values);

    if (result.rowCount === 0) {
      return res.status(404).send('Ebeveyn bulunamadı.');
    }

    res.json({ message: 'Ebeveyn başarıyla güncellendi.', updatedParent: result.rows[0] });
  } catch (err) {
    console.error('Ebeveyn güncellenirken hata:', err);
    res.status(500).send('Ebeveyn güncellenirken bir hata oluştu.');
  }
});


// Search Parent by ID
app.get('/parents/:parent_id', async (req, res) => {
  const parentId = req.params.parent_id;
  const sql = 'SELECT * FROM ebeveynler WHERE parent_id = $1';

  try {
    const result = await db.query(sql, [parentId]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).send('Ebeveyn bulunamadı.');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Ebeveyn aranırken bir hata oluştu.');
  }
});

// Get All Parents
app.get('/parents', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM ebeveynler');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ebeveynler alınırken bir hata oluştu.');
  }
});




          /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




// Tüm ebeveynleri döndür
app.get('/api/parents', (req, res) => {
  const sql = 'SELECT parent_id, parent_name, parent_surname FROM ebeveynler';
  db.query(sql, (err, result) => {
      if (err) {
          console.error('Ebeveynleri getirirken hata:', err);
          res.status(500).send('Ebeveyn bilgileri alınamadı.');
      } else {
          res.json(result.rows);
      }
  });
});

// Çocuk ekleme
app.post('/api/children/add', async (req, res) => {
  console.log(req.body); // Gelen veriyi kontrol edin
  const { child_name, child_surname, birth_date, parent_id } = req.body;

  if (!child_name || !child_surname || !birth_date || !parent_id) {
    return res.status(400).send('Eksik veri gönderildi.');
  }

  const sql = 'CALL add_child($1, $2, $3, $4)';

  try {
    await db.query(sql, [child_name, child_surname, birth_date, parent_id]);
    res.send('Çocuk başarıyla eklendi.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Çocuk eklenirken bir hata oluştu.');
  }
});

// Tüm ebeveynleri listele
app.get('/api/parents', async (req, res) => {
  const sql = 'SELECT parent_id, parent_name, parent_surname FROM ebeveynler';
  try {
    const result = await db.query(sql);
    res.json(result.rows); // Ebeveyn listesini JSON formatında döndür
  } catch (err) {
    console.error(err);
    res.status(500).send('Ebeveynler alınırken bir hata oluştu.');
  }
});


// Çocuk silme
app.delete('/api/children/:id', (req, res) => {
  const childId = req.params.id;

  // Silme işlemi için SQL sorgusu
  const sql = 'DELETE FROM cocuklar WHERE child_id = $1 RETURNING *';

  db.query(sql, [childId], (err, result) => {
      if (err) {
          console.error('Çocuk silinirken hata oluştu:', err);
          return res.status(500).send('Çocuk silinemedi. Bir hata oluştu.');
      }

      if (result.rowCount === 0) {
          return res.status(404).send('Silmek istediğiniz çocuk bulunamadı.');
      }

      res.send('Çocuk başarıyla silindi.');
  });
});



// Çocuk güncelleme
app.put('/api/children/:id', async (req, res) => {
  const childId = parseInt(req.params.id, 10);
  const { child_name, child_surname, birth_date, parent_id } = req.body;

  const sql = `
    UPDATE cocuklar 
    SET 
      child_name = COALESCE($1, child_name),
      child_surname = COALESCE($2, child_surname),
      birth_date = COALESCE($3, birth_date),
      parent_id = COALESCE($4, parent_id)
    WHERE child_id = $5 RETURNING *`;

  try {
    const result = await db.query(sql, [child_name, child_surname, birth_date, parent_id, childId]);

    if (result.rowCount === 0) {
      return res.status(404).send('Güncellemek istediğiniz çocuk bulunamadı.');
    }

    res.json({ message: 'Çocuk başarıyla güncellendi.' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Çocuk güncellenirken bir hata oluştu.');
  }
});




// Çocuk Arama API'si
app.get('/api/children/:childId', async (req, res) => {
  const childId = parseInt(req.params.childId); // URL'den gelen çocuk ID'sini sayıya dönüştür

  if (isNaN(childId)) {
      return res.status(400).json({ message: 'Geçerli bir çocuk ID\'si girin.' });
  }

  console.log(`Aranan çocuk ID: ${childId}`); // Log: Aranan çocuk ID'si

  try {
      // Veritabanından çocuğu sorgula
      const result = await db.query('SELECT * FROM cocuklar WHERE child_id = $1', [childId]);

      console.log(`Veritabanı sonucu: ${JSON.stringify(result.rows)}`); // Log: Veritabanı sonucu

      if (result.rows.length === 0) {
          // Eğer çocuk bulunamadıysa
          return res.status(404).json({ message: 'Çocuk bulunamadı.' });
      }

      // Çocuk bulunduysa yanıtla
      res.json(result.rows[0]);
  } catch (err) {
      console.error('Çocuk aranırken bir hata oluştu:', err);
      res.status(500).json({ message: 'Çocuk aranırken bir hata oluştu.' });
  }
});




          /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



// 1. Etkinlik Ekle
app.post('/api/events/add', async (req, res) => {
  const { event_name, event_date } = req.body;

  if (!event_name || !event_date) {
    return res.status(400).send('Etkinlik adı ve tarihi zorunludur.');
  }

  const sql = 'CALL add_event($1, $2)';

  try {
    await db.query(sql, [event_name, event_date]);
    res.send('Etkinlik başarıyla eklendi.');
  } catch (err) {
    console.error('Etkinlik eklenirken bir hata oluştu:', err);
    res.status(500).send('Etkinlik eklenemedi. Bir hata oluştu.');
  }
});



// 2. Etkinlik Sil
app.delete('/api/events/:event_id', async (req, res) => {
  const { event_id } = req.params;
  
  console.log('Etkinlik silme isteği alındı, event_id:', event_id); // Debug için log ekledik

  try {
    const result = await db.query('DELETE FROM etkinlikler WHERE event_id = $1', [event_id]);
    
    console.log('Silme işlemi sonucu:', result); // Veritabanı sorgusunun sonucunu logluyoruz

    if (result.rowCount === 0) {
      console.log('Etkinlik bulunamadı!');
      return res.status(404).send('Etkinlik bulunamadı');
    }

    res.status(200).send('Etkinlik başarıyla silindi');
  } catch (err) {
    console.error('Silme hatası:', err);
    res.status(500).send('Internal Server Error');
  }
});



// 3. Etkinlik Güncelleme API'si
app.put('/api/events/:eventId', async (req, res) => {
  const { eventId } = req.params;
  const { event_name, event_date } = req.body;

  if (!event_name || !event_date) {
    return res.status(400).json({ message: 'Etkinlik adı ve tarihi zorunludur.' });
  }

  try {
    const result = await db.query(
      'UPDATE etkinlikler SET event_name = $1, event_date = $2 WHERE event_id = $3',
      [event_name, event_date, eventId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Etkinlik bulunamadı.' });
    }

    res.status(200).json({ message: 'Etkinlik başarıyla güncellendi.' });
  } catch (err) {
    console.error('Etkinlik güncellenirken bir hata oluştu:', err);
    res.status(500).json({ message: 'Etkinlik güncellenemedi. Bir hata oluştu.' });
  }
});


//4.  Etkinlik Ara API'si

app.get('/api/events/:eventId', async (req, res) => {
  const eventId = parseInt(req.params.eventId); // URL'den gelen etkinlik ID'sini sayıya dönüştür

  if (isNaN(eventId)) {
    return res.status(400).json({ message: 'Geçerli bir etkinlik ID\'si girin.' });
  }

  console.log(`Aranan etkinlik ID: ${eventId}`); // Log: Aranan etkinlik ID'si

  try {
    // Veritabanından etkinliği sorgula
    const result = await db.query('SELECT * FROM etkinlikler WHERE event_id = $1', [eventId]);

    console.log(`Veritabanı sonucu: ${JSON.stringify(result.rows)}`); // Log: Veritabanı sonucu

    if (result.rows.length === 0) {
      // Eğer etkinlik bulunamadıysa
      return res.status(404).json({ message: 'Etkinlik bulunamadı.' });
    }

    // Etkinlik bulunduysa yanıtla
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Etkinlik aranırken bir hata oluştu:', err);
    res.status(500).json({ message: 'Etkinlik aranırken bir hata oluştu.' });
  }
});

       ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Çalışanları ve Personel Türlerini Listeleme
app.get('/api/calisanlar', async (req, res) => {
  const sql = `
      SELECT calisanlar.employee_id, calisanlar.employee_name, calisanlar.employee_surname, 
             calisanlar.hire_date, calisanlar.salary,
             ogretmenler.specialization AS teacher_specialization,
             psikologlar.expertise AS psychologist_expertise,
             gorevli.job_role AS staff_role
      FROM personel.calisanlar
      LEFT JOIN personel.ogretmenler ON calisanlar.employee_id = ogretmenler.employee_id
      LEFT JOIN personel.psikologlar ON calisanlar.employee_id = psikologlar.employee_id
      LEFT JOIN personel.gorevli ON calisanlar.employee_id = gorevli.employee_id
  `;
  try {
      const result = await db.query(sql);
      res.json(result.rows);
  } catch (err) {
      console.error('Veri çekme hatası:', err);
      res.status(500).send('Çalışanlar verisi alınırken bir hata oluştu.');
  }
});

        /////////////////////////////////////////////////////////////////////////////////////////////////////////


// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
